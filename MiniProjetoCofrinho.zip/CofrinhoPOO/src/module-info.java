module CofrinhoPOO {
    // permite usar HttpClient, HttpRequest, HttpResponse
    requires java.net.http;

    // permite usar as classes com.google.gson.*
    requires com.google.gson;
    
    // se você exporta pacotes para uso externo, pode manter
    // exports app;
}
