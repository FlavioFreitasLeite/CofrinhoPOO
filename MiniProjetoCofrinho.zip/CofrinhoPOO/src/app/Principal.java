package app;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) throws Exception {             // ← agora pode lançar IOException, InterruptedException
        // 1) cria o serviço de câmbio USD→BRL e EUR→BRL  <<< passo 4: instanciar ExchangeRateService
        ExchangeRateService usdService = new ExchangeRateService("USD");   // <<< aqui
        double usdToBrl = usdService.getRate("BRL");                       // <<< aqui

        ExchangeRateService eurService = new ExchangeRateService("EUR");   // <<< aqui
        double eurToBrl = eurService.getRate("BRL");                       // <<< aqui

        Cofrinho cof = new Cofrinho();
        Scanner sc = new Scanner(System.in);
        int opc;

        do {
            System.out.println("\n=== COFRINHO ===");
            System.out.println("1. Adicionar moeda");
            System.out.println("2. Remover moeda");
            System.out.println("3. Listar moedas");
            System.out.println("4. Total convertido p/ Real");
            System.out.println("0. Sair");
            System.out.print("Escolha: ");
            opc = sc.nextInt();

            switch (opc) {
                case 1:
                    System.out.print("Tipo (R)Real, (D)Dólar, (E)Euro: ");
                    char tipo = sc.next().toUpperCase().charAt(0);
                    System.out.print("Valor: ");
                    double v = sc.nextDouble();
                    Moeda m;
                    switch (tipo) {
                        case 'D':
                            // usa a cotação dinâmica obtida lá no passo 4
                            m = new Dolar(v, usdToBrl);     // <<< aqui
                            break;
                        case 'E':
                            m = new Euro(v, eurToBrl);      // <<< aqui
                            break;
                        default:
                            m = new Real(v);                // Real continua igual
                            break;
                    }
                    cof.adicionar(m);
                    break;

                case 2:
                    System.out.print("Tipo moeda a remover (R/D/E): ");
                    char t2 = sc.next().toUpperCase().charAt(0);
                    System.out.print("Valor: ");
                    double v2 = sc.nextDouble();
                    Moeda m2;
                    if (t2 == 'D')
                        m2 = new Dolar(v2, usdToBrl);         // <<< aqui
                    else if (t2 == 'E')
                        m2 = new Euro(v2, eurToBrl);          // <<< aqui
                    else
                        m2 = new Real(v2);
                    cof.remover(m2);
                    break;

                case 3:
                    cof.listar();
                    break;

                case 4:
                    System.out.printf("Total em R$ %.2f%n", cof.totalConvertido());
                    break;

                case 0:
                    System.out.println("Tchau!");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }
        } while (opc != 0);

        sc.close();
    }
}
