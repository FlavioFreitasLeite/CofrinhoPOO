package app;

public class Dolar extends Moeda {
    private double cotacao;    // agora variável de instância

    // recebe valor em USD e a cotação atual de USD→BRL
    public Dolar(double valor, double cotacao) {
        super(valor);
        this.cotacao = cotacao;
    }

    @Override
    public double converterParaReal() {
        return valor * cotacao; 
    }
}
