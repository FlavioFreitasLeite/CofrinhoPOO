package app;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Classe que representa um "cofrinho" capaz de armazenar várias Moedas
public class Cofrinho {

    // Lista que guarda objetos do tipo Moeda (pode ser Real, Dolar, Euro, etc.)
    private List<Moeda> moedas = new ArrayList<>();

    /**
     * Adiciona uma moeda ao cofrinho.
     * @param m objeto Moeda (p.ex. new Dolar(10))
     */
    public void adicionar(Moeda m) {
        moedas.add(m);                        // insere no ArrayList
        System.out.println("Adicionado: " + m);  // feedback para o usuário
    }

    /**
     * Remove a primeira ocorrência de uma moeda igual à informada.
     * Compara classe e valor exato.
     * @param m moeda a ser removida
     * @return true se conseguiu remover, false caso contrário
     */
    public boolean remover(Moeda m) {
        // Usa Iterator para poder remover durante a iteração com segurança
        Iterator<Moeda> it = moedas.iterator();
        while (it.hasNext()) {
            Moeda atual = it.next();
            // verifica mesmo tipo (getClass) e mesmo valor
            if (atual.getClass().equals(m.getClass())
                && atual.getValor() == m.getValor()) {
                it.remove();                          // remove do ArrayList
                System.out.println("Removido: " + m); // feedback
                return true;                          // encerra após remover
            }
        }
        // se saiu do loop, não encontrou a moeda
        System.out.println("Moeda não encontrada: " + m);
        return false;
    }

    /**
     * Exibe todas as moedas atualmente no cofrinho.
     * Se estiver vazio, avisa que não há moedas.
     */
    public void listar() {
        if (moedas.isEmpty()) {
            System.out.println("Cofrinho vazio.");
        } else {
            System.out.println("Moedas no cofrinho:");
            // para cada moeda, chama toString() (exibe valor e tipo)
            for (Moeda m : moedas) {
                System.out.println(" - " + m);
            }
        }
    }

    /**
     * Calcula o total de todas as moedas convertidas para Reais.
     * @return soma em R$
     */
    public double totalConvertido() {
        double total = 0;
        // percorre cada moeda e usa polimorfismo no converterParaReal()
        for (Moeda m : moedas) {
            total += m.converterParaReal();
        }
        return total;
    }
}
