package app;

// Classe concreta que representa a moeda Real, estende a classe abstrata Moeda
public class Real extends Moeda {

    /**
     * Construtor: recebe um valor em Reais e repassa ao construtor da superclasse.
     * @param valor quantidade de Reais
     */
    public Real(double valor) {
        super(valor);  // inicializa o campo 'valor' definido em Moeda
    }

    /**
     * Implementação do método abstrato converterParaReal().
     * Como já estamos em Reais, retorna o próprio valor.
     * @return valor em R$
     */
    @Override
    public double converterParaReal() {
        return valor;  // 1 Real corresponde a 1 Real
    }
}
