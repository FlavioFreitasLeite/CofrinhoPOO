package app;

// Euro.java — converte o valor em Euros para Reais usando cotação dinâmica
public class Euro extends Moeda {

    private double cotacao;    // cotação EUR→BRL obtida em tempo de execução

    // Construtor recebe valor em Euros e a cotação atual
    public Euro(double valor, double cotacao) {
        super(valor);
        this.cotacao = cotacao;
    }

    // Sobrescreve converterParaReal() para aplicar a cotação
    @Override
    public double converterParaReal() {
        return valor * cotacao;
    }
}  // ← só esta chave fecha a classe
