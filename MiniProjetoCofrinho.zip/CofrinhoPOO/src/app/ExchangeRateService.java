package app;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.io.IOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Busca cotações de câmbio em tempo real usando ExchangeRate-API (open.er-api.com).
 */
public class ExchangeRateService {
    private static final String API_URL = "https://open.er-api.com/v6/latest/";
    private JsonObject rates;

    /**
     * Constrói o serviço para uma moeda base (ex.: "USD" ou "EUR") e já carrega as taxas.
     */
    public ExchangeRateService(String baseCurrency) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(API_URL + baseCurrency))
            .build();
        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
        JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
        this.rates = json.getAsJsonObject("rates");  // contém pares currency→valor :contentReference[oaicite:0]{index=0}
    }

    /**
     * Retorna a cotação (baseCurrency→targetCurrency), por exemplo BRL.
     */
    public double getRate(String targetCurrency) {
        return rates.get(targetCurrency).getAsDouble();  // ex.: "BRL" :contentReference[oaicite:1]{index=1}
    }
}
