package app;

// Classe abstrata que representa uma moeda genérica.
// Não pode ser instanciada diretamente; serve de base para Real, Dolar, Euro, etc.
public abstract class Moeda {
    
    // valor armazena a quantidade da moeda na sua unidade original
    protected double valor;        

    // Construtor: inicializa a moeda com o valor informado pelo usuário
    public Moeda(double valor) {
        this.valor = valor;
    }

    // Retorna o valor numérico da moeda
    public double getValor() {
        return valor;
    }

    // Método abstrato: cada subclasse deve definir como converter seu valor para reais
    public abstract double converterParaReal();
    
    // Sobrescreve toString() para exibir, por exemplo, "10.00 Dolar" ou "5.50 Euro"
    @Override
    public String toString() {
        // "%.2f" formata o número com duas casas decimais
        // this.getClass().getSimpleName() obtém o nome da subclasse em tempo de execução
        return String.format("%.2f %s", valor, this.getClass().getSimpleName());
    }
}
